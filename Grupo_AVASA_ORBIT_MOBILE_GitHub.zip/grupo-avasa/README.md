# GRUPO AVASA | ORBIT MOBILE

Sitio web institucional estático para presentar a Grupo AVASA y su proyecto de telecomunicaciones ORBIT MOBILE.

## Archivos
- `index.html`: estructura y contenido del sitio.
- `styles.css`: identidad visual, diseño adaptable y componentes.
- `script.js`: menú móvil y año dinámico.

## Publicar en GitHub Pages
1. Crea un repositorio público llamado `grupo-avasa`.
2. Sube los tres archivos principales (`index.html`, `styles.css`, `script.js`) y este README a la raíz.
3. En GitHub abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`, y guarda.
6. GitHub Pages publicará el sitio en `https://TU-USUARIO.github.io/grupo-avasa/`.

## Dominio personalizado
Cuando el dominio y el hosting estén configurados, se puede publicar en `https://grupoavasa.mx/`. Para el apartado de ORBIT MOBILE, la ruta prevista en el comunicado es `https://grupoavasa.mx/orbitmobile`.

## Contenido y precisión
La información del proyecto se basa en el comunicado corporativo fechado el 22 de noviembre de 2026. El comunicado reporta un avance estimado de 56% y una disponibilidad inicial prevista para el tercer trimestre de 2027. Estas cifras y fechas son estimaciones sujetas a cambios. La referencia a Altán Redes describe la infraestructura contemplada, conforme a los acuerdos y condiciones técnicas y comerciales correspondientes.

El sitio no afirma que el servicio ya esté disponible, que exista cobertura activa ni que los trámites estén concluidos. No se han añadido precios, planes, mapas de cobertura, canales de venta ni datos de contacto no proporcionados.

## Personalización
Los colores principales están definidos al inicio de `styles.css` mediante variables CSS. El contenido se puede editar directamente en `index.html`.
